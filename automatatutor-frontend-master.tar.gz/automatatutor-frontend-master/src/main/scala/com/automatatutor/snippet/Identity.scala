package com.automatatutor.snippet

import scala.xml.NodeSeq

class Identity {
	def render ( xhtml : NodeSeq ) : NodeSeq = xhtml
}