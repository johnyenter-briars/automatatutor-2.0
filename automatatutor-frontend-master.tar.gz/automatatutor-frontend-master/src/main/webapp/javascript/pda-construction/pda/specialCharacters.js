'use strict';

const epsilonEdit = 'E';
const epsilonDisplay = '\u03F5';

export default {epsilonEdit, epsilonDisplay};