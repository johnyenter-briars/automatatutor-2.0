﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomataPDL.PDA.DPDA.DPDAEquivalence
{
    internal class Tableau
    {
        //TODO: run the Algo, using a frontChain for the current nodes; in every step, check whether there is an unsuccessfull node (stop then and return false)
        //and filter all nodes, which are not sucessfull yet
    }
}
