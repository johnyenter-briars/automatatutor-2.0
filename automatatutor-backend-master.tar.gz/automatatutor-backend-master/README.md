# automatatutor-backend

The following section explains how to get the backend of Automata Tutor running

## Prerequisites

The website is written in C# and uses .Net Framework 4.5. The easiest way to run the code is to use Visual Studio >2014.
Visual Studio Community 2015 is free and you can download it from the Microsoft website.

## Initial configuration

Open AutomataPDL.sln using Visual Studio and set WebServicePDL as your start up project.
If you run the solution this will start a web serice on localhost:53861/Service1.asmx that offers the grading and feedback capabilities of Automata Tutor.
